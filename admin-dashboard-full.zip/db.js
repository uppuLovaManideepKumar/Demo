
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./data.db');

// Initialize tables
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE,
    password TEXT
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    name TEXT,
    email TEXT,
    created_at TEXT
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY,
    title TEXT,
    content TEXT,
    created_at TEXT
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY,
    product TEXT,
    amount REAL,
    created_at TEXT
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY,
    name TEXT,
    email TEXT,
    message TEXT,
    created_at TEXT
  )`);

  // Insert default admin if not exists (username: admin, password: admin123)
  const bcrypt = require('bcryptjs');
  const pw = 'admin123';
  const hashed = bcrypt.hashSync(pw, 8);
  db.get("SELECT * FROM admins WHERE username = ?", ['admin'], (err, row) => {
    if (!row) {
      db.run("INSERT INTO admins (username, password) VALUES (?, ?)", ['admin', hashed]);
      console.log('Default admin created: username=admin password=admin123');
    }
  });

  // Insert sample data if empty
  db.get("SELECT COUNT(*) as c FROM users", (err, row) => {
    if (row && row.c === 0) {
      const now = new Date().toISOString();
      const stmt = db.prepare("INSERT INTO users (name,email,created_at) VALUES (?,?,?)");
      stmt.run("Aman","aman@example.com",now);
      stmt.run("Priya","priya@example.com",now);
      stmt.run("Rahul","rahul@example.com",now);
      stmt.finalize();
    }
  });

});
module.exports = db;
