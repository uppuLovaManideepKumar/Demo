async function doLogin(){
  const u = document.getElementById('username').value;
  const p = document.getElementById('password').value;
  document.getElementById('err').innerText = '';
  try {
    const res = await fetch('/api/auth/login', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ username: u, password: p })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Login failed');
    localStorage.setItem('adminToken', data.token);
    window.location.href = '/index.html';
  } catch (e) {
    document.getElementById('err').innerText = e.message;
  }
}
