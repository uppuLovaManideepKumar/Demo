async function loadOverview(){
  const token = localStorage.getItem('adminToken');
  const headers = token ? { 'Authorization': 'Bearer ' + token } : {};
  const [users, posts, msgs, sales] = await Promise.all([
    fetch('/api/users',{headers}).then(r=>r.json()).catch(()=>[]),
    fetch('/api/posts',{headers}).then(r=>r.json()).catch(()=>[]),
    fetch('/api/messages',{headers}).then(r=>r.json()).catch(()=>[]),
    fetch('/api/sales',{headers}).then(r=>r.json()).catch(()=>[])
  ]);
  document.getElementById('userCount').innerText = users.length;
  document.getElementById('postCount').innerText = posts.length;
  document.getElementById('msgCount').innerText = msgs.length;
  document.getElementById('salesCount').innerText = sales.length;

  const ctx = document.getElementById('overviewChart');
  if (ctx) {
    new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Users','Posts','Messages','Sales'],
        datasets: [{ label:'Count', data:[users.length, posts.length, msgs.length, sales.length] }]
      }
    });
  }
}
loadOverview();