async function api(path, opts={}){
  const token = localStorage.getItem('adminToken');
  opts.headers = opts.headers || {};
  if (token) opts.headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch('/api' + path, opts);
  if (!res.ok) {
    const err = await res.json().catch(()=>({error:'Error'}));
    alert(err.error || 'Request failed');
    return null;
  }
  return res.json();
}
async function loadUsers(){
  const data = await api('/users');
  if (!data) return;
  const t = document.getElementById('userTable');
  t.innerHTML = '';
  data.forEach(u=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${u.id}</td><td>${u.name}</td><td>${u.email}</td><td>${new Date(u.created_at).toLocaleString()}</td>
    <td><button onclick="editUser(${u.id},'${encodeURIComponent(u.name)}','${encodeURIComponent(u.email)}')">Edit</button>
    <button onclick="delUser(${u.id})">Delete</button></td>`;
    t.appendChild(tr);
  });
}
function showAddUser(){
  const name = prompt('Name:');
  const email = prompt('Email:');
  if (!name || !email) return;
  api('/users', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({name,email}) })
    .then(()=>loadUsers());
}
function editUser(id,nameEnc,emailEnc){
  const name = decodeURIComponent(nameEnc);
  const email = decodeURIComponent(emailEnc);
  const nn = prompt('Name:', name);
  const ee = prompt('Email:', email);
  if (!nn || !ee) return;
  api('/users/'+id, { method:'PUT', headers:{'Content-Type':'application/json'}, body: JSON.stringify({name:nn,email:ee}) })
    .then(()=>loadUsers());
}
function delUser(id){
  if (!confirm('Delete user?')) return;
  api('/users/'+id, { method:'DELETE' }).then(()=>loadUsers());
}
loadUsers();