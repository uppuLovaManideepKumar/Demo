
const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware } = require('./auth');

router.get('/', authMiddleware, (req, res) => {
  db.all("SELECT * FROM posts ORDER BY id DESC", [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});
router.post('/', authMiddleware, (req, res) => {
  const { title, content } = req.body;
  const now = new Date().toISOString();
  db.run("INSERT INTO posts (title,content,created_at) VALUES (?,?,?)", [title,content,now], function(err) {
    if (err) return res.status(500).json({error: err.message});
    res.json({ id: this.lastID });
  });
});
router.put('/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  const { title, content } = req.body;
  db.run("UPDATE posts SET title=?, content=? WHERE id=?", [title,content,id], function(err) {
    if (err) return res.status(500).json({error: err.message});
    res.json({ changed: this.changes });
  });
});
router.delete('/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  db.run("DELETE FROM posts WHERE id=?", [id], function(err) {
    if (err) return res.status(500).json({error: err.message});
    res.json({ deleted: this.changes });
  });
});

module.exports = router;
