
const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware } = require('./auth');

// public: submit message
router.post('/', (req, res) => {
  const { name, email, message } = req.body;
  const now = new Date().toISOString();
  db.run("INSERT INTO messages (name,email,message,created_at) VALUES (?,?,?,?)", [name,email,message,now], function(err) {
    if (err) return res.status(500).json({error: err.message});
    res.json({ id: this.lastID });
  });
});

// admin: list & delete
router.get('/', authMiddleware, (req, res) => {
  db.all("SELECT * FROM messages ORDER BY id DESC", [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});
router.delete('/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  db.run("DELETE FROM messages WHERE id=?", [id], function(err) {
    if (err) return res.status(500).json({error: err.message});
    res.json({ deleted: this.changes });
  });
});

module.exports = router;
