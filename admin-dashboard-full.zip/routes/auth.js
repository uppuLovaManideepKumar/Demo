
const express = require('express');
const router = express.Router();
const db = require('../db');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const SECRET = 'change_this_secret';

// Login
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get("SELECT * FROM admins WHERE username = ?", [username], (err, row) => {
    if (err) return res.status(500).json({error: err.message});
    if (!row) return res.status(401).json({error: 'Invalid credentials'});
    const match = bcrypt.compareSync(password, row.password);
    if (!match) return res.status(401).json({error: 'Invalid credentials'});
    const token = jwt.sign({ id: row.id, username: row.username }, SECRET, { expiresIn: '8h' });
    res.json({ token });
  });
});

// simple middleware to validate token
function authMiddleware(req, res, next) {
  const auth = req.headers['authorization'];
  if (!auth) return res.status(401).json({ error: 'No token' });
  const token = auth.split(' ')[1];
  jwt.verify(token, SECRET, (err, decoded) => {
    if (err) return res.status(401).json({ error: 'Invalid token' });
    req.admin = decoded;
    next();
  });
}

module.exports = router;
module.exports.authMiddleware = authMiddleware;
