
const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware } = require('./auth');

// List users
router.get('/', authMiddleware, (req, res) => {
  db.all("SELECT * FROM users ORDER BY id DESC", [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});

// Create user
router.post('/', authMiddleware, (req, res) => {
  const { name, email } = req.body;
  const now = new Date().toISOString();
  db.run("INSERT INTO users (name,email,created_at) VALUES (?,?,?)", [name,email,now], function(err) {
    if (err) return res.status(500).json({error: err.message});
    res.json({ id: this.lastID });
  });
});

// Update
router.put('/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  const { name, email } = req.body;
  db.run("UPDATE users SET name=?, email=? WHERE id=?", [name,email,id], function(err) {
    if (err) return res.status(500).json({error: err.message});
    res.json({ changed: this.changes });
  });
});

// Delete
router.delete('/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  db.run("DELETE FROM users WHERE id=?", [id], function(err) {
    if (err) return res.status(500).json({error: err.message});
    res.json({ deleted: this.changes });
  });
});

module.exports = router;
