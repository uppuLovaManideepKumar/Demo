
const express = require('express');
const router = express.Router();
const db = require('../db');
const { authMiddleware } = require('./auth');

router.get('/', authMiddleware, (req, res) => {
  db.all("SELECT * FROM sales ORDER BY id DESC", [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
  });
});
router.post('/', authMiddleware, (req, res) => {
  const { product, amount } = req.body;
  const now = new Date().toISOString();
  db.run("INSERT INTO sales (product,amount,created_at) VALUES (?,?,?)", [product,amount,now], function(err) {
    if (err) return res.status(500).json({error: err.message});
    res.json({ id: this.lastID });
  });
});
router.delete('/:id', authMiddleware, (req, res) => {
  const { id } = req.params;
  db.run("DELETE FROM sales WHERE id=?", [id], function(err) {
    if (err) return res.status(500).json({error: err.message});
    res.json({ deleted: this.changes });
  });
});

module.exports = router;
